import React, { useEffect, useRef, useState } from "react";

export default function MonsterHeadCatcherGame() {
  const BASE_WIDTH = 900;
  const BASE_HEIGHT = 500;
  const MAX_MISSES = 10;

  const monsterImages = [
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/151.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/7.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/4.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/1.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/52.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/143.png",
    "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/54.png"
  ];

  const [heads, setHeads] = useState([]);
  const [score, setScore] = useState(0);
  const [missed, setMissed] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [started, setStarted] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(false);

  const gameLoopRef = useRef(null);
  const spawnLoopRef = useRef(null);

  useEffect(() => {
    const checkScreen = () => setIsSmallScreen(window.innerWidth < 700);
    checkScreen();
    window.addEventListener("resize", checkScreen);
    return () => window.removeEventListener("resize", checkScreen);
  }, []);

  const createHead = () => {
    const size = isSmallScreen
      ? Math.floor(Math.random() * 28) + 78
      : Math.floor(Math.random() * 45) + 60;

    return {
      id: Math.random().toString(36).substring(2),
      x: Math.random() * (BASE_WIDTH - size),
      y: -size,
      size,
      speed: isSmallScreen ? Math.random() * 1.7 + 2.1 : Math.random() * 2 + 2,
      rotation: Math.random() * 20 - 10,
      image: monsterImages[Math.floor(Math.random() * monsterImages.length)]
    };
  };

  const startGame = () => {
    setHeads([]);
    setScore(0);
    setMissed(0);
    setGameOver(false);
    setStarted(true);
  };

  useEffect(() => {
    if (!started || gameOver) return;

    spawnLoopRef.current = setInterval(() => {
      setHeads((prev) => [...prev, createHead()]);
    }, isSmallScreen ? 950 : 850);

    gameLoopRef.current = setInterval(() => {
      setHeads((prev) =>
        prev
          .map((head) => ({ ...head, y: head.y + head.speed }))
          .filter((head) => {
            if (head.y > BASE_HEIGHT) {
              setMissed((m) => m + 1);
              return false;
            }
            return true;
          })
      );
    }, 20);

    return () => {
      clearInterval(spawnLoopRef.current);
      clearInterval(gameLoopRef.current);
    };
  }, [started, gameOver, isSmallScreen]);

  useEffect(() => {
    if (missed >= MAX_MISSES) {
      setGameOver(true);
      clearInterval(spawnLoopRef.current);
      clearInterval(gameLoopRef.current);
    }
  }, [missed]);

  const catchHead = (id) => {
    if (gameOver) return;
    setHeads((prev) => prev.filter((head) => head.id !== id));
    setScore((s) => s + 1);
  };

  return (
    <div className="game-page">
      <div className="game-shell">
        <div className="game-header">
          <div>
            <h1 className="game-title">Can You Catch Them All???</h1>
            <p className="game-subtitle">How many can you catch before they get away!</p>
          </div>

          <div className="score-row">
            <div className="score-pill">Score: {score}</div>
            <div className="score-pill">Missed: {missed} / {MAX_MISSES}</div>
          </div>
        </div>

        <div className="board-wrap">
          <div className="game-board">
            <div className="background">
              <div className="pixel cloud" style={{ top: "8%", left: "8%", width: "10%", height: "7%" }} />
              <div className="pixel cloud" style={{ top: "11%", left: "15%", width: "15%", height: "8%" }} />
              <div className="pixel cloud" style={{ top: "7%", left: "28%", width: "8%", height: "5%", opacity: 0.8 }} />
              <div className="pixel cloud" style={{ top: "17%", right: "32%", width: "12%", height: "6%", opacity: 0.85 }} />
              <div className="pixel cloud" style={{ top: "12%", right: "12%", width: "15%", height: "8%" }} />

              <div className="pixel tree-line" style={{ bottom: "29%", left: 0, width: "100%", height: "19%" }} />
              <div className="pixel round-tree" style={{ bottom: "30%", left: 0, width: "15%", height: "25%", background: "#26884a" }} />
              <div className="pixel round-tree" style={{ bottom: "31%", left: "12%", width: "20%", height: "28%", background: "#32a052" }} />
              <div className="pixel round-tree" style={{ bottom: "30%", right: "15%", width: "22%", height: "30%", background: "#2f9b50" }} />
              <div className="pixel round-tree" style={{ bottom: "32%", right: 0, width: "17%", height: "28%", background: "#237a43" }} />

              <div className="pixel grass-1" style={{ bottom: "22%", left: 0, width: "100%", height: "13%" }} />
              <div className="pixel grass-2" style={{ bottom: "24%", left: 0, width: "100%", height: "3%" }} />
              <div className="pixel grass-3" style={{ bottom: "20%", left: 0, width: "100%", height: "6%" }} />

              <div className="pixel grass-hi" style={{ bottom: "27%", left: "10%", width: "4%", height: "1.5%" }} />
              <div className="pixel grass-hi" style={{ bottom: "25%", left: "28%", width: "6%", height: "1.5%" }} />
              <div className="pixel grass-hi" style={{ bottom: "28%", right: "28%", width: "5%", height: "1.5%" }} />
              <div className="pixel grass-hi" style={{ bottom: "26%", right: "12%", width: "7%", height: "1.5%" }} />

              <div className="pixel" style={{ bottom: "21%", left: "1%", width: "20%", height: "45%" }}>
                <div className="pixel trunk" style={{ bottom: 0, left: "46%", width: "8%", height: "50%" }} />
                <div className="pixel leaf-1" style={{ bottom: "34%", left: "2%", width: "70%", height: "45%" }} />
                <div className="pixel leaf-2" style={{ bottom: "65%", left: "58%", width: "55%", height: "36%" }} />
                <div className="pixel leaf-3" style={{ bottom: "72%", left: "67%", width: "40%", height: "23%" }} />
              </div>

              <div className="pixel" style={{ bottom: "21%", right: 0, width: "23%", height: "51%" }}>
                <div className="pixel trunk-dark" style={{ bottom: 0, left: "40%", width: "8%", height: "53%" }} />
                <div className="pixel leaf-4" style={{ bottom: "35%", left: "5%", width: "75%", height: "44%" }} />
                <div className="pixel leaf-5" style={{ bottom: "66%", left: "46%", width: "60%", height: "36%" }} />
                <div className="pixel leaf-3" style={{ bottom: "76%", left: "54%", width: "45%", height: "18%" }} />
              </div>

              <div className="pixel dirt" style={{ bottom: 0, left: 0, width: "100%", height: "22%" }}>
                <div className="pixel dirt-top" style={{ top: 0, left: 0, width: "100%", height: "18%" }} />
                <div className="pixel rock" style={{ top: "22%", left: "6%", width: "6%", height: "28%" }} />
                <div className="pixel rock" style={{ top: "48%", left: "28%", width: "4%", height: "22%" }} />
                <div className="pixel rock" style={{ top: "28%", left: "48%", width: "7%", height: "28%" }} />
                <div className="pixel rock" style={{ top: "52%", right: "28%", width: "5%", height: "23%" }} />
                <div className="pixel rock" style={{ top: "24%", right: "8%", width: "8%", height: "32%" }} />
                <div className="pixel rock-dark" style={{ top: "58%", right: "3%", width: "4%", height: "22%" }} />
              </div>
            </div>

            {!started && (
              <div className="overlay">
                <h2>Get Ready Trainer!</h2>
                <p>Don't let them escape! Miss {MAX_MISSES} and it's game over.</p>
                <button onClick={startGame} className="main-button">Start Game</button>
              </div>
            )}

            {gameOver && (
              <div className="overlay game-over">
                <h2>Better Luck Next Time</h2>
                <p>Final Score: {score}</p>
                <button onClick={startGame} className="main-button green">Play Again</button>
              </div>
            )}

            {heads.map((head) => (
              <button
                key={head.id}
                onPointerDown={() => catchHead(head.id)}
                className="monster-button"
                style={{
                  left: `${(head.x / BASE_WIDTH) * 100}%`,
                  top: `${(head.y / BASE_HEIGHT) * 100}%`,
                  width: `${(head.size / BASE_WIDTH) * 100}%`,
                  aspectRatio: "1 / 1",
                  minWidth: isSmallScreen ? 58 : 44,
                  transform: `rotate(${head.rotation}deg)`
                }}
                aria-label="Catch monster head"
              >
                <img src={head.image} alt="monster head" draggable={false} />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
