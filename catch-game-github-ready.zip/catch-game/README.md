# Can You Catch Them All???

A simple family-friendly browser game built with React and Vite.

## Run locally

```bash
npm install
npm run dev
```

## Build for publishing

```bash
npm run build
```

## Publish options

### Easiest option: Netlify or Vercel
Upload this whole project folder, or connect the GitHub repository.

### GitHub Pages note
This is a Vite React app. GitHub Pages works best if you add a GitHub Actions deploy workflow or use a hosting service like Netlify/Vercel connected to your GitHub repo.
